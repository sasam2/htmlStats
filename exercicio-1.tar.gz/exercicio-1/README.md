# htmlStats
node.js CLI for html resources statistics .

Usage:

Start application: node app.js
	- Insert http or https address
	    Ex: Insert address: https://nodejs.org/en/
    - html source is printed on console
	- dom object is printed on console
	- js object with meta info is printed on console 
    - json with meta info is printed on console

Run tests:
	mocha ./test/tests.js -R spec
