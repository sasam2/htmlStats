var htmlStats = require('./htmlStats.js')
htmlStats.readLine();
